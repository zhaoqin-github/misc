LBAAS_DEVICE = 'LBAAS_DEVICE'
LBAAS_DEVICE_PREFIX = "/lbaas"

# Device provisioning or operating status
IDLE = "IDLE"
ONLINE = "ONLINE"
